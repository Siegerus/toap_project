
<header class="l-header">

    <div class="header__cont max-cont-width">

        <div class="header__cont-logo">
            <a 
                title="<?php echo htmlspecialchars(MG::getSetting('sitename')) ?>"
                href="<?php echo SITE ?>">
                    <?php echo mgLogo(); ?>
                <p>
                    Таврическое объединение аналитических <br />
                    психологов и психоаналитиков
                </p>
            </a>
        </div>

        <button class="header__burge-btn" onclick="burgMenuOnOff()">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </button>
    <div class="header__cont-nav" onclick="burgMenuOnOff()">

<!--  -->

        <?php
        // ! Компонент меню страниц – menu/pages  - в шапке работает тут нет!?!?!?!
            component('menu/pages', $data['menuPages']) ?>
        </div>
<!--  -->

    <?php $phones = explode(', ', MG::getSetting('shopPhone'));
        foreach ($phones as $phone) { ?>
            <div class="header__cont-num">
                <svg
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    >
                    <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M8.172 15.829C12.017 19.674 15.58 20.095 16.626 20.134C17.89 20.18 19.18 19.148 19.738 18.091C18.848 17.047 17.689 16.237 16.42 15.359C15.671 16.107 14.748 17.497 13.519 16.999C12.82 16.718 11.094 15.923 9.586 14.414C8.078 12.905 7.283 11.18 7 10.482C6.502 9.251 7.896 8.326 8.645 7.577C7.767 6.287 6.971 5.098 5.929 4.253C4.857 4.813 3.819 6.093 3.866 7.374C3.905 8.42 4.326 11.983 8.172 15.829ZM16.552 22.133C15.112 22.08 11.031 21.516 6.757 17.243C2.484 12.969 1.921 8.889 1.867 7.448C1.787 5.252 3.469 3.119 5.412 2.286C5.64598 2.18497 5.9022 2.1465 6.15553 2.17438C6.40886 2.20225 6.65059 2.29551 6.857 2.445C8.465 3.618 9.574 5.395 10.527 6.787C10.7252 7.07645 10.8161 7.4261 10.7837 7.77545C10.7514 8.12479 10.598 8.45184 10.35 8.7L8.994 10.057C9.309 10.752 9.95 11.95 11 13C12.05 14.05 13.248 14.691 13.944 15.006L15.299 13.65C15.5478 13.401 15.8763 13.2474 16.2269 13.2161C16.5776 13.1848 16.9281 13.2779 17.217 13.479C18.637 14.463 20.305 15.556 21.521 17.113C21.6826 17.3209 21.7854 17.5684 21.8187 17.8296C21.8519 18.0909 21.8144 18.3562 21.71 18.598C20.873 20.551 18.755 22.214 16.552 22.133Z"
                    />
                </svg>
                <a 
                    href="tel:<?php echo htmlspecialchars(str_replace(' ', '', $phone)); ?>">
                    <span itemprop="telephone">
                        <?php echo htmlspecialchars($phone); ?>
                    </span>
                </a>
            </div>
        <?php } ?>
    </div>  
</header>