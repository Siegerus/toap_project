<div <?php echo $attrs ?> class="swiper-slide mg-slider__slide mg-slide mg-slider__slide_html">
    <?php if(is_array($slide)) echo $slide['html'] ?>
</div>