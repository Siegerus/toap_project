<?php
$lang = array(
    "CATALOG" => "Catalog",
);