<?php
$lang = array(
    "CATALOG" => "Каталог",
);