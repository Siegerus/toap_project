<?php
mgAddMeta('components/modal/modal.js');
mgAddMeta('components/modal/modal.css');
?>
<div class="c-modal c-modal--700"
     id="js-modal__default">
    <div class="c-modal__wrap">
        <div class="c-modal__content">
            <div class="c-modal__close">
                <svg class="icon icon--close">
                    <use xlink:href="#icon--close"></use>
                </svg>
            </div>

           **Контент слайда**

        </div>
    </div>
</div>
