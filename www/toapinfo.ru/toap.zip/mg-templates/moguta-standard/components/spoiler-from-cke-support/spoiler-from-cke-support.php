<?php
mgAddMeta('components/spoiler-from-cke-support/spoiler-from-cke-support.js');
mgAddMeta('components/spoiler-from-cke-support/spoiler-from-cke-support.css');
