<?php
 /**
 *  Файл представления 404  - выводит ошибку '404' в случае если страница не существует.
 * 
 *   @author Авдеев Марк <mark-avdeev@mail.ru>
 *   @package moguta.cms
 *   @subpackage Views
 */

?>

<?php echo lang('error404'); ?>